<?php 
    $this->_pageTitle = '';
    
    if(!isset($title)) $title = '';
    if(!isset($text)) $text = '';
?>

<h1 class="title"><?= $title; ?></h1>
<div class="block-body">
    
    <?= $text; ?>
    
    <h2>Welcome to ApPHP Survey!</h2>
    <br>

    <p>ApPHP Survey is a fully featured web solution allows non-technical users to create create surveys and polls, send them to anyone, administer them, gather results, and view statistics, all managed online after database initialization.</p>

    <p>There is no restriction in the number of surveys and polls, with a single installation users can add and manage polls unlimited. Do you need a lightweight surveys & poll script with back-end admin panel and auto-installation script? This is exactly what are you looking for!</p>
    
    <p>With this script you can provide votes and polls system on your website or send it to your clients. Your visitors select one or more options and click the submit button to vote.</p>
    
    <br>

	<?php if($hasTestData): ?>
		<div class="alert alert-warning">To check our test survey click: <a href="surveys/login/code/AMB6S0P8JA">TEST Survey</a>.</div>
    <?php endif; ?>
    <br>

</div>
