<?php 
    $this->_pageTitle = '';
    
    if(!isset($title)) $title = '';
    if(!isset($text)) $text = '';
?>

<h1 class="title"><?= $title; ?></h1>
<div class="block-body">
    <div class="text-center">
        <img src="/images/logo.jpg">
        <h2>Please Check Survey Links</h2>
    </div>
</div>
