
DELETE FROM `<DB_PREFIX>modules` WHERE `code` = 'setup';
DELETE FROM `<DB_PREFIX>module_settings` WHERE `module_code` = 'setup';


