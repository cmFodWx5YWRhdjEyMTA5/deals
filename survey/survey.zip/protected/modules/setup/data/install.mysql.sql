
INSERT INTO `<DB_PREFIX>modules` (`id`, `code`, `class_code`, `name`, `description`, `version`, `icon`, `show_on_dashboard`, `show_in_menu`, `is_installed`, `is_system`, `is_active`, `installed_at`, `updated_at`, `sort_order`) VALUES
(NULL, 'setup', 'Setup', 'Setup', 'Setup module allows to install application using web installation wizard', '0.1.0', 'icon.png', 0, 0, 1, 1, 1, '<CURRENT_DATETIME>', NULL, 0);

