<?php

return array(
	// Default Backend url (optional, if defined - will be used as application default settings)
	'backendDefaultUrl' => 'backup/create'
);
