<?php
    Website::setMetaTags(array('title'=>A::t('app', 'Test Checkout')));
?>

<h1><?= A::t('app', 'Test Checkout'); ?></h1>

<div class="bloc">
	<br>
		
	Complete!!!
    
</div>
