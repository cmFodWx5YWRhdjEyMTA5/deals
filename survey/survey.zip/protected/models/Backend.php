<?php
/**
 * Backend model
 *
 * PUBLIC:                 	PROTECTED:                 	PRIVATE:
 * ---------------         	---------------            	---------------
 * __construct
 *
 */

class Backend extends CModel
{

    /**
	 * Class default constructor
     */
    public function __construct()
    {
        parent::__construct();
    }

}
