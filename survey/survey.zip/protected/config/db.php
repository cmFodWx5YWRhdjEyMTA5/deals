<?php            
return array(
    // database settings
    'db' => array(
        'driver' 	=> 'mysql',
		'socket' 	=> '',
        'host' 		=> 'localhost',
		'port' 		=> '3306',
        'database' 	=> 'deals',
        'username' 	=> 'root',
        'password' 	=> '',
        'prefix' 	=> 'surv_',
        'charset' 	=> 'utf8',
        'schema' 	=> ''
    )               
);