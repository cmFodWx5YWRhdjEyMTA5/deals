<?php            
return array(
    // database settings
    'db' => array(
        'driver' 	=> 'mysql',
		'socket' 	=> '',
        'host' 		=> 'localhost',
		'port' 		=> '3306',
        'database' 	=> 'bddeals_db',
        'username' 	=> 'bddeals_user',
        'password' 	=> 'bdde@ls2015',
        'prefix' 	=> 'surv_',
        'charset' 	=> 'utf8',
        'schema' 	=> ''
    )               
);